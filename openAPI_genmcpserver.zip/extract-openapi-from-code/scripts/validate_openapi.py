#!/usr/bin/env python3
"""
Validate an OpenAPI YAML spec for structural well-formedness.

Usage:
    python3 validate_openapi.py <path-to-openapi.yaml>

Exit codes:
    0  — valid
    1  — invalid (error printed to stderr)
"""

import sys
import yaml


def validate(path: str) -> None:
    with open(path) as f:
        doc = yaml.safe_load(f)

    # Required top-level keys
    missing = [k for k in ["openapi", "info", "paths"] if k not in doc]
    if missing:
        sys.exit(f"ERROR: Missing required top-level keys: {missing}")

    # openapi version format
    version = doc.get("openapi", "")
    if not str(version).startswith(("3.0", "3.1")):
        sys.exit(f"ERROR: Unexpected openapi version: {version!r} (expected 3.x.x)")

    # info fields
    info = doc.get("info", {})
    for field in ("title", "version"):
        if not info.get(field):
            sys.exit(f"ERROR: info.{field} is missing or empty")

    # paths non-empty
    paths = doc.get("paths", {})
    if not paths:
        sys.exit("ERROR: paths object is empty")

    # Collect all operationIds
    http_methods = {"get", "post", "put", "patch", "delete", "head", "options", "trace"}
    op_ids = []
    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue
        for method, operation in path_item.items():
            if method.lower() not in http_methods:
                continue
            if not isinstance(operation, dict):
                continue
            op_id = operation.get("operationId")
            if op_id:
                op_ids.append((path, method.upper(), op_id))
            else:
                print(f"WARN: {method.upper()} {path} has no operationId", file=sys.stderr)

    # Duplicate operationId check
    seen, dupes = set(), set()
    for _, _, op_id in op_ids:
        if op_id in seen:
            dupes.add(op_id)
        seen.add(op_id)
    if dupes:
        sys.exit(f"ERROR: Duplicate operationIds found: {sorted(dupes)}")

    # $ref resolution check (inline only — no external file refs)
    schemas = set((doc.get("components") or {}).get("schemas", {}).keys())

    def check_refs(node):
        if isinstance(node, dict):
            if "$ref" in node:
                ref = node["$ref"]
                if ref.startswith("#/components/schemas/"):
                    name = ref.split("/")[-1]
                    if name not in schemas:
                        sys.exit(f"ERROR: Unresolved $ref: {ref!r}")
            for v in node.values():
                check_refs(v)
        elif isinstance(node, list):
            for item in node:
                check_refs(item)

    check_refs(doc)

    # Summary
    print("YAML well-formed.")
    print(f"Paths ({len(paths)}): {', '.join(paths.keys())}")
    print(f"OperationIds ({len(op_ids)}): {', '.join(oid for _, _, oid in op_ids)}")
    if schemas:
        print(f"Schemas ({len(schemas)}): {', '.join(sorted(schemas))}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(f"Usage: python3 {sys.argv[0]} <path-to-openapi.yaml>")
    validate(sys.argv[1])
