# OpenAPI YAML Validation Rules

Rules for confirming that a generated `openapi.yaml` is well-formed. Apply these in order after every extraction run. All checks are REQUIRED before the skill reports completion.

---

## Rule 1 — Parse Check (no syntax errors)

The file must load as valid YAML without parse errors.

**Preferred tool (Node.js, available in most JS/TS projects):**

```bash
node -e "
const yaml = require('js-yaml');
const fs   = require('fs');
try {
  yaml.load(fs.readFileSync('openapi.yaml', 'utf8'));
  console.log('[PASS] YAML parses without errors');
} catch (e) {
  console.error('[FAIL] YAML parse error:', e.message);
  process.exit(1);
}
"
```

**Fallback — Ruby projects:**

```bash
ruby -ryaml -e "YAML.load_file('openapi.yaml'); puts '[PASS] YAML parses without errors'"
```

**Fallback — PHP projects:**

```bash
php -r "
\$yaml = yaml_parse_file('openapi.yaml');
if (\$yaml === false) { echo '[FAIL] YAML parse error' . PHP_EOL; exit(1); }
echo '[PASS] YAML parses without errors' . PHP_EOL;
"
```

**Fallback — manual (when no runtime is available):** Read the file and check for common syntax errors: inconsistent indentation mixing tabs and spaces, unquoted special characters (`:`, `{`, `}`), missing colons after keys, unclosed block scalars.

---

## Rule 2 — Required Top-Level Keys

The parsed document must contain all three keys: `openapi`, `info`, `paths`.

```bash
node -e "
const yaml = require('js-yaml');
const fs   = require('fs');
const doc  = yaml.load(fs.readFileSync('openapi.yaml', 'utf8'));
const required = ['openapi', 'info', 'paths'];
const missing  = required.filter(k => !doc[k]);
if (missing.length) {
  console.error('[FAIL] Missing required top-level keys:', missing.join(', '));
  process.exit(1);
}
console.log('[PASS] All required top-level keys present');
"
```

---

## Rule 3 — OpenAPI Version Format

The `openapi` field must match the pattern `3.x.x` (OpenAPI 3.0.x or 3.1.x).

**Check:** After loading, verify `doc.openapi` starts with `"3."`.

Accepted values: `3.0.0`, `3.0.1`, `3.0.2`, `3.0.3`, `3.1.0`.

```bash
node -e "
const yaml = require('js-yaml');
const doc  = yaml.load(require('fs').readFileSync('openapi.yaml', 'utf8'));
if (!/^3\\./.test(doc.openapi || '')) {
  console.error('[FAIL] openapi version must be 3.x.x, got:', doc.openapi);
  process.exit(1);
}
console.log('[PASS] openapi version:', doc.openapi);
"
```

---

## Rule 4 — Info Object Completeness

`info.title` and `info.version` must be non-empty strings.

```bash
node -e "
const yaml = require('js-yaml');
const doc  = yaml.load(require('fs').readFileSync('openapi.yaml', 'utf8'));
const info = doc.info || {};
const errs = [];
if (!info.title)   errs.push('info.title is missing or empty');
if (!info.version) errs.push('info.version is missing or empty');
if (errs.length) { console.error('[FAIL]', errs.join('; ')); process.exit(1); }
console.log('[PASS] info.title:', info.title, '| info.version:', info.version);
"
```

---

## Rule 5 — Paths Object is Non-Empty

`paths` must have at least one entry. An empty `paths: {}` means no endpoints were extracted.

```bash
node -e "
const yaml  = require('js-yaml');
const doc   = yaml.load(require('fs').readFileSync('openapi.yaml', 'utf8'));
const count = Object.keys(doc.paths || {}).length;
if (count === 0) { console.error('[FAIL] paths object is empty — no endpoints extracted'); process.exit(1); }
console.log('[PASS] paths count:', count);
"
```

---

## Rule 6 — Every Operation Has a Unique operationId

Each HTTP method object under `paths` must have an `operationId` that is unique across the whole spec.

```bash
node -e "
const yaml = require('js-yaml');
const doc  = yaml.load(require('fs').readFileSync('openapi.yaml', 'utf8'));
const HTTP_METHODS = ['get','post','put','patch','delete','options','head','trace'];
const seen = {};
const errs = [];
for (const [path, methods] of Object.entries(doc.paths || {})) {
  for (const method of HTTP_METHODS) {
    const op = methods[method];
    if (!op) continue;
    if (!op.operationId) {
      errs.push(method.toUpperCase() + ' ' + path + ' is missing operationId');
    } else if (seen[op.operationId]) {
      errs.push('Duplicate operationId: ' + op.operationId);
    } else {
      seen[op.operationId] = true;
    }
  }
}
if (errs.length) { errs.forEach(e => console.error('[FAIL]', e)); process.exit(1); }
console.log('[PASS] All operations have unique operationIds:', Object.keys(seen).join(', '));
"
```

---

## Rule 7 — $ref Resolution (spot check)

Every `$ref` value that starts with `#/components/` must resolve to a key that exists in `components`.

```bash
node -e "
const yaml = require('js-yaml');
const fs   = require('fs');
const raw  = fs.readFileSync('openapi.yaml', 'utf8');
const doc  = yaml.load(raw);
const refs = [...raw.matchAll(/\\\$ref:\s*['\"]?(#\/[^'\" \\n]+)/g)].map(m => m[1]);
const errs = [];
for (const ref of refs) {
  const parts = ref.replace('#/', '').split('/');
  let node = doc;
  for (const part of parts) {
    node = node?.[part];
    if (node === undefined) { errs.push('Unresolved \$ref: ' + ref); break; }
  }
}
if (errs.length) { errs.forEach(e => console.error('[FAIL]', e)); process.exit(1); }
console.log('[PASS] All local \$refs resolve (' + refs.length + ' checked)');
"
```

---

## Validation Checklist (for Extraction Summary)

Copy this block verbatim into the Extraction Summary and tick each item:

```markdown
### YAML Validation

- [ ] Rule 1 — File parses without syntax errors
- [ ] Rule 2 — `openapi`, `info`, `paths` top-level keys present
- [ ] Rule 3 — `openapi` version is `3.x.x`
- [ ] Rule 4 — `info.title` and `info.version` are non-empty
- [ ] Rule 5 — `paths` is non-empty (≥1 endpoint)
- [ ] Rule 6 — Every operation has a unique `operationId`
- [ ] Rule 7 — All `$ref` values resolve to defined components
```

Mark each item `[x]` (pass) or `[!]` (fail with note) based on actual tool output. Do not mark any item without running the corresponding check.

---

## Severity

| Rule | Severity | Meaning if it fails |
|------|----------|---------------------|
| 1 — Parse | **BLOCKER** | File is invalid YAML — do not proceed |
| 2 — Top-level keys | **BLOCKER** | Spec is not a valid OpenAPI document |
| 3 — Version | **BLOCKER** | Tooling cannot process spec |
| 4 — Info | **ERROR** | Client generation will produce unnamed SDKs |
| 5 — Non-empty paths | **BLOCKER** | Nothing was extracted — re-run extraction |
| 6 — operationIds | **ERROR** | Operations get generic names; fix before use |
| 7 — $ref resolution | **ERROR** | Broken references cause client generation failure |

Any BLOCKER failure must be fixed before the skill reports completion. ERROR failures must be listed in the Gaps & Notes section of the Extraction Summary.
