---
name: extract-openapi-from-code
description: Use when extracting or generating an OpenAPI spec from existing API code. Triggers on "extract OpenAPI", "code first", "generate spec from code", "Spring Boot OpenAPI", "NestJS swagger", "Rails swagger", "Laravel OpenAPI", "existing API code"
license: Apache-2.0
---

# extract-openapi-from-code

Extract an OpenAPI specification from an existing API codebase. Covers four major frameworks across Java, TypeScript, Ruby, and PHP.

## Content Guides

| Framework | Language | Guide |
|-----------|----------|-------|
| Spring Boot | Java | [content/frameworks/spring-boot.md](content/frameworks/spring-boot.md) |
| NestJS | TypeScript | [content/frameworks/nestjs.md](content/frameworks/nestjs.md) |
| Hono | TypeScript | [content/frameworks/hono.md](content/frameworks/hono.md) |
| Rails | Ruby | [content/frameworks/rails.md](content/frameworks/rails.md) |
| Laravel | PHP | [content/frameworks/laravel.md](content/frameworks/laravel.md) |

Each guide provides detailed setup, schema definition, authentication, and troubleshooting for that framework.

## When to Use

- User has an existing API and wants to generate an OpenAPI spec from it
- User mentions a specific framework (Spring Boot, NestJS, Hono, Rails, Laravel)
- User says: "extract OpenAPI", "code first", "generate spec from code", "existing API code"

## Inputs

| Input | Required | Description |
|-------|----------|-------------|
| Framework | Yes | The API framework in use (see Decision Framework) |
| Project path | Yes | Root directory of the API project |
| Output path | No | Where to write the spec (default: `openapi.yaml`) |

## Outputs

Every run of this skill MUST produce all three of the following:

| Output | Description |
|--------|-------------|
| `openapi.yaml` | OpenAPI 3.1.0 spec written to the project root (or specified output path) |
| Extraction Summary | Markdown report written inline summarising what was found and generated |
| YAML validation result | Confirmation that the generated file is well-formed, per [rules/yaml-validation.md](rules/yaml-validation.md) |

## Prerequisites

- The API project must be buildable and its dependencies installed
- For runtime extraction (Spring Boot, NestJS, Hono), the app must be importable or startable

## Decision Framework

Use this tree to determine the extraction method:

| Framework | Language | Method | Requires Running Server? |
|-----------|----------|--------|--------------------------|
| Spring Boot (springdoc) | Java | HTTP endpoint | Yes |
| NestJS | TypeScript | HTTP endpoint or export script | Yes |
| Hono (zod-openapi) | TypeScript | Programmatic export | No |
| Rails (rswag) | Ruby | Rake task | No |
| Laravel (l5-swagger) | PHP | Artisan command | No |

**Fallback — no OpenAPI library present:** If the framework has no OpenAPI library configured, read all controller/route files, models, and exception handlers, then hand-craft the spec from the source code. Document in the Extraction Summary that the spec was hand-crafted and list any endpoints that could not be fully inferred.

## Extraction Commands

### Java: Spring Boot

Requires [springdoc-openapi](https://springdoc.org/). Start the application, then fetch the spec:

```bash
# Start the app (background)
./mvnw spring-boot:run &
# Wait for startup
sleep 15

# Fetch YAML spec
curl http://localhost:8080/v3/api-docs.yaml -o openapi.yaml

# Stop the app
kill %1
```

If the server runs on a different port or context path, adjust the URL accordingly.

If springdoc is not in the `pom.xml`, read all `@RestController` and `@RequestMapping` classes, plus all model and exception-handler classes, and hand-craft `openapi.yaml`.

### TypeScript: NestJS

Requires [@nestjs/swagger](https://docs.nestjs.com/openapi/introduction). Start the application, then fetch:

```bash
# Start the app (background)
npm run start &
sleep 10

# Fetch the spec (default path with SwaggerModule)
curl http://localhost:3000/api-yaml -o openapi.yaml

# Stop the app
kill %1
```

Alternatively, export without running the server:

```typescript
// scripts/export-openapi.ts
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from '../src/app.module';
import * as fs from 'fs';
import * as yaml from 'js-yaml';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { logger: false });
  const config = new DocumentBuilder().setTitle('API').setVersion('1.0.0').build();
  const doc = SwaggerModule.createDocument(app, config);
  fs.writeFileSync('openapi.yaml', yaml.dump(doc));
  await app.close();
}
bootstrap();
```

Run with:

```bash
npx tsx scripts/export-openapi.ts
```

### TypeScript: Hono (zod-openapi)

Requires [@hono/zod-openapi](https://github.com/honojs/middleware/tree/main/packages/zod-openapi). Export the schema programmatically:

```typescript
// scripts/export-openapi.ts
import { app } from '../src/app';
import * as fs from 'fs';
import * as yaml from 'js-yaml';

const doc = app.doc('/doc', {
  openapi: '3.1.0',
  info: { title: 'API', version: '1.0.0' },
});
fs.writeFileSync('openapi.yaml', yaml.dump(doc));
```

Run with:

```bash
npx tsx scripts/export-openapi.ts
```

### Ruby: Rails (rswag)

Requires [rswag](https://github.com/rswag/rswag):

```bash
rails rswag:specs:swaggerize
```

The spec is written to `swagger/v1/swagger.yaml` by default. Copy or symlink it to `openapi.yaml` at the project root for consistency.

### PHP: Laravel (l5-swagger)

Requires [l5-swagger](https://github.com/DarkaOnLine/L5-Swagger):

```bash
php artisan l5-swagger:generate
```

The spec is written to `storage/api-docs/api-docs.json` by default. Convert to YAML and copy to `openapi.yaml`:

```bash
node -e "
const fs = require('fs');
const yaml = require('js-yaml');
const json = JSON.parse(fs.readFileSync('storage/api-docs/api-docs.json', 'utf8'));
fs.writeFileSync('openapi.yaml', yaml.dump(json));
console.log('Converted to openapi.yaml');
"
```

## Post-Extraction Steps

After producing `openapi.yaml`, always run both steps below before reporting done.

### Step 1 — Validate YAML well-formedness

Follow [rules/yaml-validation.md](rules/yaml-validation.md) in full. Use the bundled validation script:

```bash
python3 ~/.claude/skills/extract-openapi-from-code/scripts/validate_openapi.py <path-to-openapi.yaml>
```

The script ([scripts/validate_openapi.py](scripts/validate_openapi.py)) checks:
- Required top-level keys (`openapi`, `info`, `paths`)
- `openapi` version is `3.x.x`
- `info.title` and `info.version` are present
- `paths` is non-empty
- All `operationId` values are unique
- All `$ref` values resolve to a defined schema in `components/schemas`

Exit code `0` = valid. Any error prints to stderr and exits with code `1`.

### Step 2 — Produce the Extraction Summary

Write the Extraction Summary as a markdown block immediately after validation. It must follow this template exactly:

```markdown
## Extraction Summary

**Framework:** <framework name> (<extraction method: runtime | hand-crafted | rake task | artisan>)
**Spec version:** OpenAPI 3.1.0
**Output file:** <relative path to openapi.yaml>

### API Surface

| Method | Path | Operation ID | Description |
|--------|------|--------------|-------------|
| GET    | /foo | getFoo       | ... |

### Schemas

| Schema | Source file | Fields |
|--------|-------------|--------|
| Foo    | Foo.java    | id, name, ... |

### Error Responses Modelled

| HTTP Status | Trigger | Schema |
|-------------|---------|--------|
| 400         | ...     | ErrorResponse |
| 500         | ...     | ErrorResponse |

### YAML Validation

- [ ] File parses without errors
- [ ] `openapi` field present and is `3.x.x`
- [ ] `info.title` and `info.version` present
- [ ] `paths` object is non-empty
- [ ] Every operation has a unique `operationId`
- [ ] Every `$ref` resolves to a defined schema

### Gaps & Notes

> List any endpoints that could not be fully inferred, missing auth schemes,
> or response bodies that defaulted to `object` due to missing model classes.
```

## Common Issues After Extraction

| Issue | Symptom | Fix |
|-------|---------|-----|
| Missing operationIds | Generic or duplicate operation names | Add unique `operationId` to each endpoint in source or hand-crafted spec |
| Missing descriptions | No documentation in generated spec | Add descriptions to endpoints and schemas in source code |
| Overly permissive schemas | Schemas use `additionalProperties: true` or lack type constraints | Tighten schemas using stricter model annotations |
| No response schemas | Return types are `object` with no properties | Add explicit response model classes to framework endpoints |
| Duplicate operationIds | Validation fails | Ensure each endpoint has a unique `operationId` |
| Missing authentication | No security schemes in spec | Add security metadata to framework config |
| YAML parse error | File has invalid syntax | Re-extract; check for debug output polluting the file |

## What NOT to Do

- **Do NOT** skip the Extraction Summary — it is a required output
- **Do NOT** skip YAML validation — even a hand-crafted spec must pass the well-formedness check
- **Do NOT** hand-write a spec when the framework can generate one — always extract first
- **Do NOT** assume the extracted spec is complete — frameworks may omit auth, error responses, or headers
- **Do NOT** start the server in production mode for extraction — use development or test configuration

## Troubleshooting

| Error | Cause | Solution |
|-------|-------|----------|
| Connection refused (Spring Boot, NestJS) | Server not fully started | Increase sleep time or poll for readiness |
| Empty or minimal spec | Routes not registered at import time | Ensure all route modules are imported; check lazy loading |
| YAML parse error | Extracted file has invalid syntax | Re-extract; check for print/log statements polluting stdout |
| `Cannot find module` (Node.js) | Dependencies not installed | Run `npm install` or `yarn install` |
| No `/v3/api-docs` endpoint (Spring Boot) | springdoc not configured | Add `springdoc-openapi-starter-webmvc-ui` to dependencies |
| No `/api-json` endpoint (NestJS) | Swagger module not set up | Configure `SwaggerModule.setup(app, ...)` in `main.ts` |
