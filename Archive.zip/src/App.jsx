import React, { useRef, useState } from 'react';
import JsonFormRenderer from './components/JsonFormRenderer';

import schema1 from './schemas/modelFormSchema_1.json';
import schema2 from './schemas/modelFormSchema_2.json';

import data1 from './data/data_1.json';
import data2 from './data/data_2.json';

function App() {
  const formRef = useRef(null);

  const [selectedSchemaKey, setSelectedSchemaKey] = useState('schema1');
  const [selectedDataKey, setSelectedDataKey] = useState('data1');

  const schemas = {
    schema1: { label: 'modelFormSchema_1.json (Governance)', schema: schema1 },
    schema2: { label: 'modelFormSchema_2.json (Assessment)', schema: schema2 }
  };

  const datasets = {
    data1: { label: 'data_1.json', data: data1 },
    data2: { label: 'data_2.json', data: data2 }
  };

  const handleSchemaChange = (e) => {
    const key = e.target.value;
    setSelectedSchemaKey(key);
  };

  const handleDataChange = (e) => {
    const key = e.target.value;
    setSelectedDataKey(key);
    const dataset = datasets[key].data;
    if (formRef.current) {
      formRef.current.setFormData(dataset);
    }
  };

  const handleReload = () => {
    const dataset = datasets[selectedDataKey].data;
    if (formRef.current) {
      formRef.current.setFormData(dataset);
    }
    alert(`Loaded ${datasets[selectedDataKey].label} into ${schemas[selectedSchemaKey].label}!`);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1100px', margin: '0 auto' }}>
      <h2>Enterprise Form Engine - Multi-Schema & Multi-Version Console</h2>
      
      <div style={{ marginBottom: '15px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <label style={{ fontWeight: 'bold', fontSize: '12px' }}>Form Schema:</label>
          <select 
            value={selectedSchemaKey} 
            onChange={handleSchemaChange}
            style={{ padding: '6px', borderRadius: '4px', border: '1px solid #cbd5e1', fontWeight: 'bold' }}
          >
            <option value="schema1">schema_1 (Governance)</option>
            <option value="schema2">schema_2 (Assessment)</option>
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <label style={{ fontWeight: 'bold', fontSize: '12px' }}>Data Version:</label>
          <select 
            value={selectedDataKey} 
            onChange={handleDataChange}
            style={{ padding: '6px', borderRadius: '4px', border: '1px solid #cbd5e1', fontWeight: 'bold' }}
          >
            <option value="data1">data_1.json</option>
            <option value="data2">data_2.json</option>
          </select>
        </div>

        <button 
          onClick={handleReload} 
          style={{ background: '#1b365d', color: '#fff', border: 'none', padding: '7px 14px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          Load Data
        </button>

        <button 
          onClick={() => console.log("Retrieved Form Payload:", formRef.current.getFormData())} 
          style={{ background: '#0f766e', color: '#fff', border: 'none', padding: '7px 14px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          Get Data (Console)
        </button>
      </div>

      <JsonFormRenderer
        key={selectedSchemaKey}
        ref={formRef}
        schema={schemas[selectedSchemaKey].schema}
        initialData={datasets[selectedDataKey].data}
        onSubmit={(data) => alert("Submitted Data:\n" + JSON.stringify(data, null, 2))}
        onSaveDraft={(data) => alert("Draft Saved:\n" + JSON.stringify(data, null, 2))}
      />
    </div>
  );
}

export default App;