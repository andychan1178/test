import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import './FormRenderer.css';

const JsonFormRenderer = forwardRef(({ schema, initialData = {}, onSubmit, onSaveDraft }, ref) => {
  const [activeTab, setActiveTab] = useState(schema.tabs[0]?.tabId);
  const [formData, setFormData] = useState({});
  const [collapsedSections, setCollapsedSections] = useState({});

  // Reset/sync form values whenever schema or initialData changes
  useEffect(() => {
    const mergedValues = {};
    schema.tabs.forEach(tab => {
      tab.sections.forEach(section => {
        section.fields.forEach(field => {
          mergedValues[field.name] = initialData[field.name] ?? field.defaultValue ?? (field.type === 'boolean' ? false : '');
        });
      });
    });
    setFormData(mergedValues);
  }, [schema, initialData]);

  // Expose JS API / methods to parent component via ref
  useImperativeHandle(ref, () => ({
    getFormData: () => formData,
    setFormData: (newData) => setFormData(prev => ({ ...prev, ...newData })),
    resetForm: () => setFormData({})
  }));

  const handleInputChange = (fieldName, value) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  const toggleSection = (sectionId) => {
    setCollapsedSections(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const renderField = (field) => {
    const value = formData[field.name] ?? (field.type === 'boolean' ? false : '');

    switch (field.type) {
      case 'singleLineText':
      case 'autoNumber':
      case 'date':
        return (
          <input
            type={field.type === 'date' ? 'date' : 'text'}
            className="form-control"
            value={value}
            disabled={field.disabled}
            placeholder={field.placeholder || ''}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
          />
        );
      case 'multiLineText':
        return (
          <textarea
            className="form-control"
            rows={3}
            value={value}
            placeholder={field.placeholder || ''}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
          />
        );
      case 'boolean':
        return (
          <label className="checkbox-inline">
            <input
              type="checkbox"
              checked={Boolean(value)}
              onChange={(e) => handleInputChange(field.name, e.target.checked)}
            /> Yes / No
          </label>
        );
      case 'singleSelect':
        return (
          <select
            className="form-control"
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
          >
            <option value="">-- Select --</option>
            {field.options?.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        );
      case 'multiSelect':
        return (
          <div className="checkbox-group">
            {field.options?.map(opt => {
              const selectedList = Array.isArray(value) ? value : [];
              const isChecked = selectedList.includes(opt.value);
              return (
                <label key={opt.value} className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => {
                      const updated = e.target.checked
                        ? [...selectedList, opt.value]
                        : selectedList.filter(v => v !== opt.value);
                      handleInputChange(field.name, updated);
                    }}
                  />
                  {opt.label}
                </label>
              );
            })}
          </div>
        );
      default:
        return (
          <input
            type="text"
            className="form-control"
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
          />
        );
    }
  };

  const currentTabObj = schema.tabs.find(t => t.tabId === activeTab);

  return (
    <div className="json-form-container">
      {/* Form Tabs Navigation Bar */}
      <div className="form-tabs-header">
        {schema.tabs.map(tab => (
          <button
            key={tab.tabId}
            className={`tab-btn ${activeTab === tab.tabId ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.tabId)}
            type="button"
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Sections & Fields Container */}
      <div className="form-tab-content">
        {currentTabObj?.sections.map(section => (
          <div key={section.sectionId} className="form-section-card">
            <div 
              className="section-header" 
              onClick={() => section.collapsible && toggleSection(section.sectionId)}
              style={{ cursor: section.collapsible ? 'pointer' : 'default' }}
            >
              <h3>{section.title}</h3>
              {section.description && <p className="section-desc">{section.description}</p>}
            </div>

            {(!section.collapsible || !collapsedSections[section.sectionId]) ? (
              <div 
                className="section-fields-grid" 
                style={{ gridTemplateColumns: `repeat(${section.gridColumns || 2}, minmax(0, 1fr))` }}
              >
                {section.fields.map(field => (
                  <div 
                    className="field-group" 
                    key={field.name}
                    style={{ gridColumn: `span ${field.colSpan || 1}` }}
                  >
                    <div className="label-container">
                      <label className="field-label">
                        {field.label} {field.required && <span className="required">*</span>}
                      </label>
                      {field.infoTooltip && (
                        <span className="info-icon-wrapper" title={field.infoTooltip}>
                          <span className="info-icon">i</span>
                        </span>
                      )}
                    </div>
                    {renderField(field)}
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        ))}
      </div>

      {/* Action Footer Buttons */}
      <div className="form-actions-footer">
        <button type="button" className="btn-exit">Exit Form</button>
        <button type="button" className="btn-draft" onClick={() => onSaveDraft?.(formData)}>Save as Draft</button>
        <button type="button" className="btn-submit" onClick={() => onSubmit?.(formData)}>Submit Request</button>
      </div>
    </div>
  );
});

export default JsonFormRenderer;