import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowRight,
  BookOpen,
  Home,
  Boxes,
  ChevronRight,
  GitBranch,
  KeyRound,
  Loader2,
  Menu,
  MessageSquare,
  MoonStar,
  Network,
  RefreshCw,
  Search,
  Share2,
  ShieldCheck,
  Sparkles,
  Workflow
} from 'lucide-react';
import mermaid from 'mermaid';
import { marked } from 'marked';
import { askWiki, callMcpTool, getCapabilities, getIndexJob, listMcpTools, searchWiki, startIndex } from './api/wikiApi';
import './styles.css';

mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose' });

const CACHE_PREFIX = 'ipc-knowledge-hub:v6:';
const CACHE_TTL_MS = 1000 * 60 * 60 * 24 * 2;
function normalizeRepoUrl(url) {
  let v = (url || '').trim();
  while (v.endsWith('/')) v = v.slice(0, -1);
  return v;
}
function cacheKey(repoUrl, branch = '') { return `${CACHE_PREFIX}${normalizeRepoUrl(repoUrl).toLowerCase()}::${(branch || '').trim().toLowerCase()}`; }
function getCachedWiki(repoUrl, branch = '') {
  try { const raw = localStorage.getItem(cacheKey(repoUrl, branch)); if (!raw) return null; const payload = JSON.parse(raw); if (Date.now() - payload.savedAt > CACHE_TTL_MS) return null; return payload.wiki; } catch { return null; }
}
function saveCachedWiki(repoUrl, branch, wiki) {
  try { localStorage.setItem(cacheKey(repoUrl, branch), JSON.stringify({ savedAt: Date.now(), wiki })); } catch {}
}

const SUGGESTED_REPOS = [
  { name: 'microsoft / vscode', url: 'https://github.com/microsoft/vscode', description: 'Visual Studio Code', stars: '183.9k' },
  { name: 'huggingface / transformers', url: 'https://github.com/huggingface/transformers', description: 'Model-definition framework for ML models', stars: '159.4k' },
  { name: 'microsoft / playwright', url: 'https://github.com/microsoft/playwright', description: 'Cross-browser automation and testing', stars: '70k+' },
  { name: 'spring-projects / spring-petclinic', url: 'https://github.com/spring-projects/spring-petclinic', description: 'Spring sample application', stars: '8k+' }
];

function Mermaid({ chart }) {
  const ref = useRef(null);
  useEffect(() => {
    let mounted = true;
    async function render() {
      if (!chart || !ref.current) return;
      const id = `m-${Math.random().toString(36).slice(2)}`;
      const { svg } = await mermaid.render(id, chart);
      if (mounted && ref.current) ref.current.innerHTML = svg;
    }
    render().catch(() => {
      if (ref.current) ref.current.textContent = chart;
    });
    return () => { mounted = false; };
  }, [chart]);
  return <div className="mermaid-box" ref={ref} />;
}

function Markdown({ text }) {
  const html = useMemo(() => marked.parse(text || ''), [text]);
  return <div className="markdown" dangerouslySetInnerHTML={{ __html: html }} />;
}

function useHeadingToc(markdownText) {
  return useMemo(() => {
    return (markdownText || '')
      .split('\n')
      .filter(line => /^#{2,3}\s+/.test(line))
      .map(line => {
        const title = line.replace(/^#{2,3}\s+/, '').trim();
        return {
          title,
          id: title.toLowerCase().replace(/[^a-z0-9]+/g, '-')
        };
      });
  }, [markdownText]);
}

function ArchitectureGraph({ graph }) {
  const [typeFilter, setTypeFilter] = useState('all');
  const [selected, setSelected] = useState(null);

  const nodes = graph?.nodes || [];
  const edges = graph?.edges || [];
  const types = ['all', ...Array.from(new Set(nodes.map(n => n.type))).sort()];
  const visibleNodes = nodes.filter(n => typeFilter === 'all' || n.type === typeFilter).slice(0, 90);
  const visibleIds = new Set(visibleNodes.map(n => n.id));
  const visibleEdges = edges.filter(e => visibleIds.has(e.source) && visibleIds.has(e.target)).slice(0, 180);

  const positions = useMemo(() => {
    const width = 1080;
    const grouped = visibleNodes.reduce((acc, node) => {
      acc[node.group] = [...(acc[node.group] || []), node];
      return acc;
    }, {});
    const groups = Object.keys(grouped).sort();
    const pos = {};
    groups.forEach((group, gi) => {
      const laneX = 110 + gi * Math.max(160, (width - 220) / Math.max(groups.length, 1));
      grouped[group].forEach((node, i) => {
        pos[node.id] = { x: Math.min(width - 110, laneX), y: 80 + (i % 8) * 52 + Math.floor(i / 8) * 16 };
      });
    });
    return pos;
  }, [visibleNodes]);

  const selectedNode = selected ? nodes.find(n => n.id === selected) : null;
  const connected = selected ? edges.filter(e => e.source === selected || e.target === selected).slice(0, 30) : [];

  return (
    <div className="graph-shell">
      <div className="graph-toolbar">
        <div>
          <b>Interactive architecture visualization</b>
          <span>{nodes.length} nodes · {edges.length} edges</span>
        </div>
        <div className="toolbar-actions">
          <select value={typeFilter} onChange={e => { setTypeFilter(e.target.value); setSelected(null); }}>
            {types.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
      </div>
      <div className="graph-canvas">
        <svg viewBox="0 0 1080 520" role="img">
          <defs>
            <marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L0,6 L9,3 z" />
            </marker>
          </defs>
          {visibleEdges.map(edge => {
            const s = positions[edge.source];
            const t = positions[edge.target];
            if (!s || !t) return null;
            return <line key={edge.id} x1={s.x} y1={s.y} x2={t.x} y2={t.y} className={`edge ${edge.kind}`} markerEnd="url(#arrow)" />;
          })}
          {visibleNodes.map(node => {
            const p = positions[node.id] || { x: 0, y: 0 };
            return (
              <g key={node.id} className={`node ${selected === node.id ? 'selected' : ''}`} onClick={() => setSelected(node.id)}>
                <rect x={p.x - 64} y={p.y - 20} width="128" height="40" rx="12" />
                <text x={p.x} y={p.y - 3}>{node.label.length > 18 ? `${node.label.slice(0, 17)}…` : node.label}</text>
                <text x={p.x} y={p.y + 11} className="node-type">{node.type}</text>
              </g>
            );
          })}
        </svg>
      </div>
      <div className="graph-details">
        {selectedNode ? (
          <>
            <h3>{selectedNode.label}</h3>
            <p><b>Type:</b> {selectedNode.type} · <b>Group:</b> {selectedNode.group}</p>
            <code>{selectedNode.path}</code>
            <h4>Connected relationships</h4>
            <div className="edge-list">
              {connected.map(edge => (
                <span key={edge.id}>{edge.kind}: {edge.source === selectedNode.id ? 'outbound' : 'inbound'} → {edge.label}</span>
              ))}
            </div>
          </>
        ) : (
          <p>Select a node to inspect file path, group, and connected relationships.</p>
        )}
      </div>
    </div>
  );
}

function McpPanel({ wiki, repoUrl, branch, accessToken }) {
  const [tools, setTools] = useState([]);
  const [result, setResult] = useState('');

  useEffect(() => {
    listMcpTools().then(setTools).catch(() => setTools([]));
  }, []);

  async function run(toolName) {
    const args = toolName === 'github.indexRepository'
      ? { repoUrl, branch, githubToken: accessToken || undefined }
      : toolName === 'repo.ask'
        ? { wikiId: wiki?.id, question: 'Explain the main runtime flow and cite files.' }
        : toolName === 'repo.search'
          ? { wikiId: wiki?.id, query: 'controller service repository', limit: 8 }
          : toolName === 'repo.getDependencies'
            ? { wikiId: wiki?.id, pathOrNodeId: '' }
            : { wikiId: wiki?.id };

    const data = await callMcpTool({ toolName, arguments: args });
    setResult(JSON.stringify(data, null, 2));
  }

  return (
    <section className="workspace-card mcp-panel">
      <div className="section-title"><Workflow size={18}/> MCP bridge</div>
      <p className="muted">Expose indexed repository knowledge to agentic clients through the MCP-style HTTP bridge.</p>
      <div className="tool-list">
        {tools.map(tool => (
          <button key={tool.name} disabled={!wiki && tool.name !== 'github.indexRepository'} onClick={() => run(tool.name)}>{tool.name}</button>
        ))}
      </div>
      {result && <pre className="json-output">{result}</pre>}
    </section>
  );
}

function HomeView({ repoUrl, setRepoUrl, branch, setBranch, accessToken, setAccessToken, loading, onGenerate, capabilities }) {
  return (
    <div className="home-view">
      <header className="topbar">
        <div className="topbar-brand"><BookOpen size={22}/><span>IPC Knowledge Hub</span></div>
        <div className="topbar-actions">
          <span className="soft-pill">Index your code with OpenAI</span>
          <button className="ghost-btn"><MoonStar size={16}/></button>
        </div>
      </header>

      <section className="landing-hero">
        <h1>Which repo would you like to understand?</h1>
        <form className="search-form" onSubmit={onGenerate}>
          <Search size={18}/>
          <input value={repoUrl} onChange={e => setRepoUrl(e.target.value)} placeholder="Search for repositories (or paste a link)" />
          <button disabled={loading}>{loading ? <Loader2 className="spin" size={18}/> : <ArrowRight size={18}/>}</button>
        </form>
        <div className="mini-fields">
          <input value={branch} onChange={e => setBranch(e.target.value)} placeholder="Branch optional; blank = default" />
          <div className="token-field"><KeyRound size={16}/><input value={accessToken} onChange={e => setAccessToken(e.target.value)} type="password" placeholder="GitHub PAT for private repos (optional)" /></div>
        </div>
        <div className="capability-row">
          <span className={`status-pill ${capabilities?.llmConfigured ? 'on' : 'off'}`}>
            <Sparkles size={14}/>{capabilities?.llmConfigured ? 'OpenAI ChatClient active' : 'OpenAI key not configured'}
          </span>
          <span className="status-pill"><Workflow size={14}/> MCP bridge enabled</span>
          <span className="status-pill"><Network size={14}/> Interactive architecture graph</span>
        </div>
      </section>

      <section className="repo-cards">
        <button className="repo-card add-card" onClick={onGenerate}>
          <div className="add-plus">+</div>
          <div>
            <strong>Add repo</strong>
            <p>Paste any public GitHub URL, or use a PAT for private repositories.</p>
          </div>
          <ArrowRight size={18}/>
        </button>
        {SUGGESTED_REPOS.map(repo => (
          <button key={repo.url} className="repo-card" onClick={() => setRepoUrl(repo.url)}>
            <div>
              <strong>{repo.name}</strong>
              <p>{repo.description}</p>
            </div>
            <div className="repo-meta">
              <span>★ {repo.stars}</span>
              <ArrowRight size={18}/>
            </div>
          </button>
        ))}
      </section>
    </div>
  );
}

function RepoView({ wiki, activePage, setActivePage, page, answer, question, setQuestion, chatLoading, onAsk, repoUrl, capabilities, repoState, onNewRepo, onRefresh, repoSearch, setRepoSearch, searchResults, handleRepoSearch }) {
  const toc = useHeadingToc(page?.markdown || wiki?.overview || '');

  return (
    <div className="repo-view">
      <header className="topbar repo-topbar">
        <div className="repo-title"><BookOpen size={22}/><strong>IPC Knowledge Hub</strong><span>{repoUrl.replace('https://github.com/', '')}</span></div>
        <div className="topbar-actions">
          <span className="soft-pill">{capabilities?.llmConfigured ? 'OpenAI reasoning enabled' : 'Static mode'}</span>
          <button className="action-btn" onClick={onNewRepo}><Home size={16}/> New Repo</button>
          <button className="action-btn" onClick={onRefresh}><RefreshCw size={16}/> Refresh / Re-index</button>
          <button className="action-btn"><Share2 size={16}/> Share</button>
        </div>
      </header>

      <div className="repo-layout">
        <aside className="left-nav">
          <div className="last-indexed">Last indexed: {new Date(wiki.generatedAt).toLocaleDateString()} ({wiki.id.slice(0, 6)})</div>
          {wiki.pages.map(p => (
            <button key={p.id} className={`nav-item ${activePage === p.id ? 'active' : ''}`} onClick={() => setActivePage(p.id)}>
              {p.title}
            </button>
          ))}
        </aside>

        <main className="article-column">
          <article className="article-card">
            <div className="article-header">
              <h1>{page?.title || 'Repository Overview'}</h1>
              <button className="icon-btn"><ChevronRight size={16}/></button>
            </div>
            <details className="source-files-block">
              <summary>Relevant source files</summary>
              <div className="related-files">{(page?.relatedFiles || []).slice(0, 14).map(file => <code key={file}>{file}</code>)}</div>
            </details>
            <Markdown text={page?.markdown || wiki.overview} />
          </article>

          <div className="floating-chat workspace-card">
            <div className="chat-head"><MessageSquare size={18}/> Ask IPC Knowledge Hub about this repo</div>
            <form onSubmit={onAsk} className="floating-chat-form">
              <textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="Ask deeper questions about architecture, entry points, data flow, or design rationale" />
              <button disabled={chatLoading}>{chatLoading ? 'Thinking…' : 'Ask'}</button>
            </form>
            {answer && <Markdown text={answer} />}
          </div>

          <section className="workspace-card search-panel">
          <div className="section-title"><Search size={18}/> Repository search</div>
          <form className="repo-search-form" onSubmit={handleRepoSearch}>
            <input value={repoSearch} onChange={e => setRepoSearch(e.target.value)} placeholder="Search symbols, files, modules, payment flows" />
            <button>Search</button>
          </form>
          {searchResults && <div className="search-results">
            <p className="muted">Results for <b>{searchResults.query}</b></p>
            {(searchResults.results || []).map((r, i) => <div className="search-hit" key={r.path}><code>{searchResults.citations?.[i] || r.path}</code><span>{r.preview?.slice(0, 220)}</span></div>)}
            {(!searchResults.results || searchResults.results.length === 0) && <p>No results found.</p>}
          </div>}
        </section>

        <section className="workspace-grid">
            <section className="workspace-card">
              <div className="section-title"><Boxes size={18}/> Repository summary</div>
              <Markdown text={wiki.overview} />
            </section>
            <section className="workspace-card stats-card">
              <div className="section-title"><GitBranch size={18}/> Index stats</div>
              <div className="chips">{Object.entries(wiki.languageStats || {}).map(([k, v]) => <span key={k}>{k}: {v}</span>)}</div>
              <div className="chips secondary">{Object.entries(wiki.architectureGraph?.nodeTypeStats || {}).map(([k, v]) => <span key={k}>{k}: {v}</span>)}</div>
            </section>
            <section className="workspace-card full-span">
              <ArchitectureGraph graph={wiki.architectureGraph} />
            </section>
            <section className="workspace-card full-span">
              <div className="section-title"><Network size={18}/> Mermaid architecture map</div>
              <Mermaid chart={wiki.architectureMermaid} />
            </section>
            <McpPanel wiki={wiki} repoUrl={repoState.repoUrl} branch={repoState.branch} accessToken={repoState.accessToken} />
          </section>
        </main>

        <aside className="right-rail">
          <div className="right-card">
            <div className="section-title"><ShieldCheck size={18}/> Workspace</div>
            <div className="workspace-note">Use OpenAI-backed Q&A for deeper answers. Use MCP tools when another agent needs structured repository context.</div>
          </div>
          <div className="right-card">
            <div className="section-title"><Menu size={18}/> On this page</div>
            <div className="toc-list">
              {toc.map(item => <a key={item.id} href={`#${item.id}`}>{item.title}</a>)}
              {toc.length === 0 && <span className="muted">Page headings will appear here.</span>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function App() {
  const [repoUrl, setRepoUrl] = useState('https://github.com/microsoft/playwright');
  const [branch, setBranch] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [wiki, setWiki] = useState(null);
  const [activePage, setActivePage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [jobStage, setJobStage] = useState('');
  const [repoSearch, setRepoSearch] = useState('payment controller service');
  const [searchResults, setSearchResults] = useState(null);
  const [error, setError] = useState('');
  const [question, setQuestion] = useState('Where is the main entry point and what is the overall runtime flow?');
  const [answer, setAnswer] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [capabilities, setCapabilities] = useState(null);

  useEffect(() => {
    getCapabilities().then(setCapabilities).catch(() => setCapabilities(null));
  }, []);

  async function handleGenerate(e, forceRefresh = false) {
    if (e) e.preventDefault();
    setError('');
    setAnswer('');
    setSearchResults(null);
    const normalizedRepo = normalizeRepoUrl(repoUrl);
    const normalizedBranch = (branch || '').trim();
    if (!forceRefresh) {
      const cached = getCachedWiki(normalizedRepo, normalizedBranch);
      if (cached) {
        setWiki(cached);
        setActivePage(cached.pages?.[0]?.id || null);
        setJobStage('Loaded from browser cache');
        return;
      }
    }
    setLoading(true);
    setJobStage('Submitting async indexing job...');
    try {
      const job = await startIndex({ repoUrl: normalizedRepo, branch: normalizedBranch || undefined, accessToken: accessToken || undefined });
      let status = null;
      for (let i = 0; i < 180; i++) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        status = await getIndexJob(job.jobId);
        setJobStage(`${status.stage || status.status} · ${status.progress || 0}% · ${status.message || ''}`);
        if (status.status === 'READY') {
          setWiki(status.wiki);
          setActivePage(status.wiki?.pages?.[0]?.id || null);
          saveCachedWiki(normalizedRepo, normalizedBranch, status.wiki);
          return;
        }
        if (status.status === 'FAILED') throw new Error(status.error || 'Indexing failed');
      }
      throw new Error('Indexing did not complete within the polling window. Check backend logs or reduce repository size.');
    } catch (err) {
      setError(err.message || 'Generation failed');
    } finally {
      setLoading(false);
    }
  }

  async function handleAsk(e) {
    e.preventDefault();
    if (!wiki) return;
    setChatLoading(true);
    setAnswer('');
    try {
      const data = await askWiki({ wikiId: wiki.id, question });
      const citationMarkdown = (data.citations || []).map(c => `- \`${c}\``).join('\n');
      setAnswer(`${data.answer}\n\n### Citations\n${citationMarkdown}`);
    } catch (err) {
      setAnswer(err.message || 'Q&A failed');
    } finally {
      setChatLoading(false);
    }
  }


  async function handleRepoSearch(e) {
    e.preventDefault();
    if (!wiki || !repoSearch.trim()) return;
    try {
      const data = await searchWiki(wiki.id, repoSearch, 12);
      setSearchResults(data);
    } catch (err) {
      setSearchResults({ query: repoSearch, results: [], citations: [err.message || 'Search failed'] });
    }
  }

  function handleNewRepo() {
    setWiki(null);
    setActivePage(null);
    setAnswer('');
    setError('');
  }

  const page = wiki?.pages?.find(p => p.id === activePage) || wiki?.pages?.[0];

  return (
    <div className="ipc-app">
      {error && <div className="error-banner">{error}</div>}
      {!wiki && !loading && (
        <HomeView
          repoUrl={repoUrl}
          setRepoUrl={setRepoUrl}
          branch={branch}
          setBranch={setBranch}
          accessToken={accessToken}
          setAccessToken={setAccessToken}
          loading={loading}
          onGenerate={handleGenerate}
          capabilities={capabilities}
        />
      )}
      {loading && (
        <div className="loading-screen">
          <Loader2 className="spin" size={42}/>
          <h2>Indexing repository…</h2>
          <p>{jobStage || 'Queued'}<br/>v6 uses async indexing and polling, so Nginx request timeouts are avoided.</p>
        </div>
      )}
      {wiki && !loading && (
        <RepoView
          wiki={wiki}
          activePage={activePage}
          setActivePage={setActivePage}
          page={page}
          answer={answer}
          question={question}
          setQuestion={setQuestion}
          chatLoading={chatLoading}
          onAsk={handleAsk}
          repoUrl={repoUrl}
          capabilities={capabilities}
          repoState={{ repoUrl, branch, accessToken }}
          onNewRepo={handleNewRepo}
          onRefresh={() => handleGenerate(null, true)}
          repoSearch={repoSearch}
          setRepoSearch={setRepoSearch}
          searchResults={searchResults}
          handleRepoSearch={handleRepoSearch}
        />
      )}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
