const API_BASE = import.meta.env.VITE_API_BASE || '/api';

function normalizeError(status, payload, text) {
  const message = payload?.message || text || `HTTP ${status}`;
  if (status === 504) return 'Repository indexing timed out. v6 uses async jobs; try again or increase DEEPWIKI_CLONE_TIMEOUT_SECONDS.';
  if (status === 502) return message || 'Backend failed while cloning or analyzing the repository.';
  return message;
}

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let payload = null; let text = '';
    try { payload = await res.clone().json(); } catch { text = await res.text(); }
    throw new Error(normalizeError(res.status, payload, text));
  }
  return res.json();
}

export function startIndex(payload) { return request('/wiki/index', { method: 'POST', body: JSON.stringify(payload) }); }
export function getIndexJob(jobId) { return request(`/wiki/jobs/${jobId}`); }
export function generateWiki(payload) { return request('/wiki/generate', { method: 'POST', body: JSON.stringify(payload) }); }
export function askWiki(payload) { return request('/wiki/chat', { method: 'POST', body: JSON.stringify(payload) }); }
export function searchWiki(wikiId, query, limit = 10) { return request(`/wiki/${wikiId}/search?query=${encodeURIComponent(query)}&limit=${limit}`); }
export function getCapabilities() { return request('/wiki/capabilities'); }
export function listMcpTools() { return request('/mcp/tools'); }
export function callMcpTool(payload) { return request('/mcp/tools/call', { method: 'POST', body: JSON.stringify(payload) }); }
