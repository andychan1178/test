# IPC Knowledge Hub

A React + Spring Boot 3.5 / Java 21 code-intelligence starter inspired by the DeepWiki interaction model.

It turns a source repository into:

- an explorable technical wiki
- an interactive architecture graph
- a grounded repository Q&A workspace
- an MCP-style HTTP tool bridge for agentic clients

## What this version now targets

- **Branding**: renamed to **IPC Knowledge Hub**
- **LLM reasoning**: uses **Spring AI OpenAI ChatClient** for richer repository summaries and deeper Q&A
- **Text only**: audio, transcription, image, and embedding auto-config are excluded
- **GitHub PAT support**: optional for private repos, not needed for public repos
- **Friendlier UX**: landing page and repo workspace redesigned to feel closer to the DeepWiki-style experience
- **Interactive visualization**: node filtering, dependency map, Mermaid diagram, and page navigation

## Important truth

If you want reliable deeper answers, set `OPENAI_API_KEY`.

Without it, the application still works, but the backend falls back to deterministic static analysis and template-based summaries. That is useful for structure discovery, but it is not real LLM reasoning.

## Run with Docker Compose

```bash
cp .env.example .env
# put your real OpenAI API key into .env
docker compose up --build
```

Open:

```text
http://localhost:3000
```

Backend:

```text
http://localhost:8080
```

## Required / recommended environment

```env
OPENAI_API_KEY=sk-...
SPRING_AI_OPENAI_MODEL=gpt-4o-mini
DEEPWIKI_MAX_FILES=260
DEEPWIKI_MAX_FILE_BYTES=160000
```

## Public vs private GitHub repos

### Public repositories
No GitHub Personal Access Token is required.

### Private repositories
Provide a GitHub PAT with read access. The backend uses it only for authenticated clone over HTTPS.

## MCP-style tool bridge

Exposed endpoints:

```text
GET  /api/mcp/tools
POST /api/mcp/tools/call
POST /api/mcp/rpc
```

Tools:

| Tool | Purpose |
|---|---|
| `github.indexRepository` | Clone and index a repo. Supports `githubToken` / `accessToken`. |
| `repo.search` | Retrieve targeted file context from an indexed wiki. |
| `repo.getDependencies` | Return graph edges connected to a file or node. |
| `repo.explainArchitecture` | Generate an architecture explanation from graph evidence. |
| `repo.ask` | Ask a grounded repository question. |

Example:

```bash
curl -X POST http://localhost:8080/api/mcp/tools/call   -H 'Content-Type: application/json'   -d '{
    "toolName": "github.indexRepository",
    "arguments": {
      "repoUrl": "https://github.com/spring-projects/spring-petclinic",
      "branch": "main"
    }
  }'
```

## Architecture visualization

The graph is intentionally lightweight and is built from:

- files as nodes
- Java imports as dependency edges
- TypeScript / React imports as component edges
- Spring controller/service/repository/model hints
- inferred API → service → data runtime-flow edges

## Current limits

This is still a strong starter, not a full DeepWiki replacement. Missing or partial:

- true line-level citations
- persistent vector storage
- full AST call graph
- full MCP stdio/SSE transport
- enterprise RBAC / audit / vault integration
- deep research and security audit reports


## Branch handling

Leave the branch field blank to use the repository default branch. If you enter `main` but the repository only has `master` or another branch, IPC Knowledge Hub now retries with the default branch automatically.


## v6 upgrades

- Async indexing: `POST /api/wiki/index` returns a job id immediately; the UI polls `GET /api/wiki/jobs/{jobId}`.
- Repo-specific Mermaid: the Mermaid diagram is generated from the selected repository's graph nodes and edges, not from the IPC platform architecture.
- Search: `GET /api/wiki/{wikiId}/search?query=payment&limit=10` returns ranked source evidence.
- Citation format: chat/search citations now include preview line ranges such as `src/main/java/.../PaymentService.java:1-160`.
- Client cache: generated workspaces are cached in browser `localStorage` by `repoUrl + branch`.
- Timeout handling: Nginx proxy timeout is 300 seconds; clone timeout is controlled by `DEEPWIKI_CLONE_TIMEOUT_SECONDS`.
