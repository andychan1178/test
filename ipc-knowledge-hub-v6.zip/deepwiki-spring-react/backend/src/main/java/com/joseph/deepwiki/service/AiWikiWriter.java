package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AiWikiWriter {
    private final ObjectProvider<ChatClient.Builder> chatClientBuilderProvider;

    public AiWikiWriter(ObjectProvider<ChatClient.Builder> chatClientBuilderProvider) {
        this.chatClientBuilderProvider = chatClientBuilderProvider;
    }

    public String generateOverview(String repoUrl, List<FileSummary> files, Map<String, Long> stats, ArchitectureGraph graph) {
        String prompt = """
                You are a senior software architect generating a technical overview for a source repository.
                Write concise but meaningful markdown.
                Requirements:
                - Explain what the repository appears to do.
                - Infer the stack and major module groups.
                - Explain likely runtime flow and important interactions.
                - Mention dependency hotspots or structural risks.
                - Ground all claims in the provided evidence.
                - Use file paths inline when useful.

                Repository: %s
                Language stats: %s
                Graph stats: nodes=%s edges=%s nodeTypes=%s edgeTypes=%s
                Evidence:
                %s
                """.formatted(repoUrl, stats, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), compactEvidence(files));
        return askOrFallback(prompt, fallbackOverview(repoUrl, files, stats, graph));
    }

    public String answerQuestion(String question, List<FileSummary> files, ArchitectureGraph graph) {
        String prompt = """
                You are a repository-grounded engineering assistant.
                Answer only from the supplied repository evidence.
                Make the answer practical and specific.
                Requirements:
                - answer the question directly first
                - explain how you know
                - mention likely entry points, flows, or dependencies when relevant
                - include file paths as evidence bullets at the end
                - if the evidence is incomplete, say so clearly

                Question: %s
                Graph stats: nodes=%s edges=%s nodeTypes=%s edgeTypes=%s
                Evidence:
                %s
                """.formatted(question, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), compactEvidence(files));
        return askOrFallback(prompt, fallbackAnswer(question, files, graph));
    }

    public String explainArchitecture(ArchitectureGraph graph, List<FileSummary> files) {
        String prompt = """
                Explain this repository architecture in markdown.
                Include:
                - likely entry points
                - main layers or subsystems
                - dependency hotspots
                - frontend/backend split if present
                - 3 practical questions a refactoring engineer should investigate next

                Graph nodes: %s
                Graph edges: %s
                Files: %s
                """.formatted(graph.nodes().stream().limit(80).toList(), graph.edges().stream().limit(120).toList(), files.stream().limit(30).map(FileSummary::path).toList());
        return askOrFallback(prompt, fallbackArchitecture(graph));
    }

    private String askOrFallback(String prompt, String fallback) {
        try {
            ChatClient.Builder builder = chatClientBuilderProvider.getIfAvailable();
            if (builder == null || !StringUtils.hasText(System.getenv("OPENAI_API_KEY"))) {
                return fallback;
            }
            String content = builder.build().prompt(prompt).call().content();
            return StringUtils.hasText(content) ? content : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private String compactEvidence(List<FileSummary> files) {
        return files.stream().limit(45)
                .map(f -> "PATH: " + f.path() + "\nLANG: " + f.language() + "\n" + abbreviate(f.preview(), 1800))
                .collect(Collectors.joining("\n---\n"));
    }

    private String fallbackOverview(String repoUrl, List<FileSummary> files, Map<String, Long> stats, ArchitectureGraph graph) {
        String topFiles = files.stream()
                .limit(12)
                .map(f -> "- `" + f.path() + "` — " + f.language())
                .collect(Collectors.joining("\n"));

        return """
                ## Repository overview

                This wiki was generated for `%s` using static repository inspection. For deeper explanations and more reliable reasoning, configure `OPENAI_API_KEY` so IPC Knowledge Hub can use Spring AI OpenAI ChatClient.

                ## Technology signal

                %s

                ## Architecture graph signal

                - Nodes: `%s`
                - Edges: `%s`
                - Node types: `%s`
                - Edge types: `%s`

                ## Important files sampled

                %s

                ## Initial reading path

                Start with configuration files, entry points, controllers/routes, service classes, and package/module boundaries. Then use the architecture graph and Q&A panel to ask targeted questions about flow, dependencies, and extension points.
                """.formatted(repoUrl, stats, graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats(), topFiles);
    }

    private String fallbackAnswer(String question, List<FileSummary> files, ArchitectureGraph graph) {
        String matches = files.stream()
                .limit(8)
                .map(f -> "- `" + f.path() + "`: " + abbreviate(f.preview().replace("\n", " "), 260))
                .collect(Collectors.joining("\n"));

        return """
                IPC Knowledge Hub is running in static-analysis fallback mode, so this answer is based on repository structure rather than full LLM reasoning.

                Question asked: **%s**

                Inspect these files first:

                %s

                Graph context: `%s` nodes and `%s` edges were detected. Use the Architecture Graph panel or MCP tool `repo.getDependencies` to inspect relationships.
                """.formatted(question, matches, graph.nodes().size(), graph.edges().size());
    }

    private String fallbackArchitecture(ArchitectureGraph graph) {
        return """
                ## Architecture summary

                IPC Knowledge Hub detected `%s` graph nodes and `%s` graph edges.

                ### Node types
                %s

                ### Edge types
                %s

                Use the interactive architecture graph to inspect controllers/routes, services, repositories, React components, and inferred runtime-flow edges.
                """.formatted(graph.nodes().size(), graph.edges().size(), graph.nodeTypeStats(), graph.edgeTypeStats());
    }

    private String abbreviate(String text, int max) {
        if (text == null) {
            return "";
        }
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }
}
