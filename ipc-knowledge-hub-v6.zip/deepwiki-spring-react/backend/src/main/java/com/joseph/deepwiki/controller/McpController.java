package com.joseph.deepwiki.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.joseph.deepwiki.model.WikiModels.*;
import com.joseph.deepwiki.service.McpToolService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/mcp")
@CrossOrigin(origins = "*")
public class McpController {
    private final McpToolService mcpToolService;

    public McpController(McpToolService mcpToolService) {
        this.mcpToolService = mcpToolService;
    }

    @GetMapping("/tools")
    public List<McpTool> tools() {
        return mcpToolService.tools();
    }

    @PostMapping("/tools/call")
    public ResponseEntity<McpToolCallResponse> call(@Valid @RequestBody McpToolCallRequest request) {
        return ResponseEntity.ok(mcpToolService.call(request));
    }

    /**
     * Lightweight JSON-RPC facade for MCP-like clients.
     * Supported methods: initialize, tools/list, tools/call.
     * For production, replace this with a full MCP SSE/stdio transport.
     */
    @PostMapping("/rpc")
    public Map<String, Object> rpc(@RequestBody JsonNode request) {
        Object id = request.has("id") ? request.get("id") : null;
        String method = request.path("method").asText();
        Object result = switch (method) {
            case "initialize" -> Map.of(
                    "protocolVersion", "2024-11-05",
                    "serverInfo", Map.of("name", "deepwiki-spring-mcp", "version", "0.2.0"),
                    "capabilities", Map.of("tools", Map.of())
            );
            case "tools/list" -> Map.of("tools", mcpToolService.tools());
            case "tools/call" -> {
                JsonNode params = request.path("params");
                String name = params.path("name").asText(params.path("toolName").asText());
                Map<String, Object> args = mcpToolService.jsonToMap(params.path("arguments"));
                yield mcpToolService.call(new McpToolCallRequest(name, args));
            }
            default -> throw new IllegalArgumentException("Unsupported MCP RPC method: " + method);
        };
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("jsonrpc", "2.0");
        response.put("id", id);
        response.put("result", result);
        return response;
    }
}
