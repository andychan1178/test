package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class WikiGenerationService {
    private final RepositoryAnalyzer repositoryAnalyzer;
    private final AiWikiWriter aiWikiWriter;
    private final Map<String, WikiResponse> store = new ConcurrentHashMap<>();

    public WikiGenerationService(RepositoryAnalyzer repositoryAnalyzer, AiWikiWriter aiWikiWriter) {
        this.repositoryAnalyzer = repositoryAnalyzer;
        this.aiWikiWriter = aiWikiWriter;
    }

    public WikiResponse generate(GenerateWikiRequest request) {
        RepositoryAnalyzer.AnalysisResult analysis = repositoryAnalyzer.analyze(request.repoUrl(), request.branch(), request.accessToken());
        String id = UUID.randomUUID().toString();
        String overview = aiWikiWriter.generateOverview(request.repoUrl(), analysis.files(), analysis.languageStats(), analysis.architectureGraph());
        List<WikiPage> pages = createPages(analysis.files(), analysis.architectureGraph());
        WikiResponse response = new WikiResponse(
                id,
                request.repoUrl(),
                Optional.ofNullable(request.branch()).filter(s -> !s.isBlank()).orElse("default"),
                Instant.now(),
                overview,
                repoSpecificMermaid(analysis.architectureGraph()),
                analysis.architectureGraph(),
                pages,
                analysis.files(),
                analysis.languageStats()
        );
        store.put(id, response);
        return response;
    }

    public Optional<WikiResponse> find(String id) { return Optional.ofNullable(store.get(id)); }
    public Collection<WikiResponse> list() { return store.values(); }

    public ChatResponse chat(ChatRequest request) {
        WikiResponse wiki = store.get(request.wikiId());
        if (wiki == null) throw new NoSuchElementException("Wiki not found: " + request.wikiId());
        List<FileSummary> evidence = retrieveEvidence(wiki, request.question(), 12);
        String answer = aiWikiWriter.answerQuestion(request.question(), evidence, wiki.architectureGraph());
        List<String> citations = evidence.stream().map(this::citation).toList();
        return new ChatResponse(answer, citations);
    }

    public SearchResponse search(String wikiId, String query, int limit) {
        List<FileSummary> results = searchFiles(wikiId, query, limit);
        return new SearchResponse(query, results, results.stream().map(this::citation).toList());
    }

    public List<FileSummary> searchFiles(String wikiId, String query, int limit) {
        WikiResponse wiki = store.get(wikiId);
        if (wiki == null) throw new NoSuchElementException("Wiki not found: " + wikiId);
        return retrieveEvidence(wiki, query, limit <= 0 ? 10 : limit);
    }

    public List<GraphEdge> dependencies(String wikiId, String pathOrNodeId) {
        WikiResponse wiki = store.get(wikiId);
        if (wiki == null) throw new NoSuchElementException("Wiki not found: " + wikiId);
        Set<String> ids = wiki.architectureGraph().nodes().stream()
                .filter(n -> n.id().equals(pathOrNodeId) || n.path().equals(pathOrNodeId) || n.label().equalsIgnoreCase(pathOrNodeId))
                .map(GraphNode::id)
                .collect(Collectors.toSet());
        if (ids.isEmpty() && !StringUtils.hasText(pathOrNodeId)) {
            ids = wiki.architectureGraph().nodes().stream().limit(5).map(GraphNode::id).collect(Collectors.toSet());
        }
        Set<String> finalIds = ids;
        return wiki.architectureGraph().edges().stream()
                .filter(e -> finalIds.contains(e.source()) || finalIds.contains(e.target()))
                .limit(80)
                .toList();
    }

    public String explainArchitecture(String wikiId) {
        WikiResponse wiki = store.get(wikiId);
        if (wiki == null) throw new NoSuchElementException("Wiki not found: " + wikiId);
        return aiWikiWriter.explainArchitecture(wiki.architectureGraph(), wiki.files());
    }

    private List<FileSummary> retrieveEvidence(WikiResponse wiki, String query, int limit) {
        String q = Optional.ofNullable(query).orElse("").toLowerCase(Locale.ROOT);
        Set<String> terms = Arrays.stream(q.split("[^a-zA-Z0-9_]+"))
                .filter(s -> s.length() > 2)
                .collect(Collectors.toCollection(LinkedHashSet::new));
        Comparator<FileSummary> byScore = Comparator.comparingInt((FileSummary f) -> score(f, terms)).reversed()
                .thenComparing(FileSummary::path);
        return wiki.files().stream().sorted(byScore).limit(limit).toList();
    }

    private int score(FileSummary f, Set<String> terms) {
        String haystack = (f.path() + "\n" + f.preview()).toLowerCase(Locale.ROOT);
        int score = 0;
        for (String term : terms) {
            if (f.path().toLowerCase(Locale.ROOT).contains(term)) score += 6;
            if (haystack.contains(term)) score += 2;
        }
        if (score == 0) score = f.path().toLowerCase(Locale.ROOT).contains("readme") ? 1 : 0;
        return score;
    }

    private String citation(FileSummary f) {
        int lines = Math.max(1, Math.min(160, f.preview().split("\\R", -1).length));
        return f.path() + ":1-" + lines;
    }

    private List<WikiPage> createPages(List<FileSummary> files, ArchitectureGraph graph) {
        Map<String, List<FileSummary>> byArea = files.stream().collect(Collectors.groupingBy(this::area, TreeMap::new, Collectors.toList()));
        List<WikiPage> pages = new ArrayList<>();
        pages.add(new WikiPage("architecture-map", "Architecture Map", "Repository-specific component and dependency map.", architectureMarkdown(graph), files.stream().limit(30).map(FileSummary::path).toList()));
        pages.add(new WikiPage("core-concepts", "Core Concepts", "Concepts inferred from repository files and graph nodes.", conceptsMarkdown(files, graph), files.stream().limit(25).map(FileSummary::path).toList()));
        byArea.forEach((area, areaFiles) -> pages.add(new WikiPage(slug(area), pretty(area), "Auto-generated documentation for " + pretty(area), pageMarkdown(area, areaFiles, graph), areaFiles.stream().limit(20).map(FileSummary::path).toList())));
        pages.add(new WikiPage("onboarding-guide", "Onboarding Guide", "Suggested first reading path for a new contributor.", onboardingMarkdown(files, graph), files.stream().limit(25).map(FileSummary::path).toList()));
        return pages;
    }

    private String area(FileSummary file) {
        String path = file.path().replace('\\', '/').toLowerCase(Locale.ROOT);
        if (path.contains("/controller") || path.contains("/routes") || path.contains("/api")) return "api-layer";
        if (path.contains("/service") || path.contains("/domain") || path.contains("/usecase")) return "domain-services";
        if (path.contains("/repository") || path.contains("/dao") || path.contains("/entity") || path.contains("/model")) return "data-layer";
        if (path.contains("/components") || path.endsWith(".jsx") || path.endsWith(".tsx")) return "frontend-components";
        if (path.contains("dockerfile") || path.contains("docker-compose") || path.endsWith(".yml") || path.endsWith(".yaml")) return "deployment-config";
        if (path.endsWith("readme.md") || path.endsWith(".md")) return "documentation";
        if (path.contains("/test")) return "tests";
        return "source-overview";
    }

    private String architectureMarkdown(ArchitectureGraph graph) {
        return """
                ## Repository-specific architecture visualization

                This graph is generated from this repository's files, Java imports, Spring annotations, React/TypeScript imports, and inferred runtime-flow edges.

                ### Node types

                %s

                ### Edge types

                %s

                ### How to use this map

                - Use Search to find payment, controller, service, repository, auth, config, or component terms.
                - Click graph nodes to inspect related source files.
                - Ask the repo assistant targeted questions, then use citations to jump back to source evidence.
                """.formatted(formatStats(graph.nodeTypeStats()), formatStats(graph.edgeTypeStats()));
    }

    private String conceptsMarkdown(List<FileSummary> files, ArchitectureGraph graph) {
        String nodes = graph.nodes().stream().limit(30).map(n -> "- `" + n.label() + "` — " + n.type() + " from `" + n.path() + "`").collect(Collectors.joining("\n"));
        return """
                ## Core concepts inferred from code

                These concepts are inferred from source files and graph nodes. Treat them as a starting map, then verify with citations and source files.

                %s
                """.formatted(nodes);
    }

    private String pageMarkdown(String area, List<FileSummary> files, ArchitectureGraph graph) {
        String fileBullets = files.stream().limit(25).map(f -> "- `" + f.path() + "` (" + f.language() + ", citation `" + citation(f) + "`)").collect(Collectors.joining("\n"));
        return """
                ## %s

                This section groups repository files that appear to belong to `%s`.

                ### Files and citations

                %s

                ### Graph context

                Architecture graph: `%s` nodes and `%s` edges. Use this page with Search, graph filters, and grounded Q&A to inspect inbound and outbound relationships.
                """.formatted(pretty(area), area, fileBullets, graph.nodes().size(), graph.edges().size());
    }

    private String onboardingMarkdown(List<FileSummary> files, ArchitectureGraph graph) {
        String firstFiles = files.stream()
                .filter(f -> f.path().toLowerCase(Locale.ROOT).contains("readme") || f.path().toLowerCase(Locale.ROOT).contains("application") || f.path().toLowerCase(Locale.ROOT).contains("package.json") || f.path().toLowerCase(Locale.ROOT).contains("pom.xml"))
                .limit(12)
                .map(f -> "- `" + citation(f) + "`")
                .collect(Collectors.joining("\n"));
        if (!StringUtils.hasText(firstFiles)) firstFiles = files.stream().limit(12).map(f -> "- `" + citation(f) + "`").collect(Collectors.joining("\n"));
        return """
                ## New contributor reading path

                1. Read entry/config files.
                2. Open the Architecture Map and filter by `controller`, `service`, `repository`, and `react-component`.
                3. Search for the business flow you care about, for example `payment`, `auth`, `order`, or `checkout`.
                4. Ask grounded questions and verify the cited file ranges.

                ### Suggested first files

                %s
                """.formatted(firstFiles);
    }

    private String repoSpecificMermaid(ArchitectureGraph graph) {
        StringBuilder m = new StringBuilder("flowchart LR\n");
        Map<String, List<GraphNode>> byType = graph.nodes().stream().collect(Collectors.groupingBy(GraphNode::type));
        addTypeNodes(m, "Controller", byType.getOrDefault("controller", List.of()), 4);
        addTypeNodes(m, "Service", byType.getOrDefault("service", List.of()), 5);
        addTypeNodes(m, "Repository", byType.getOrDefault("repository", List.of()), 5);
        addTypeNodes(m, "Model", byType.getOrDefault("model", List.of()), 4);
        addTypeNodes(m, "React", byType.getOrDefault("react-component", List.of()), 5);
        addTypeNodes(m, "Config", byType.getOrDefault("config", List.of()), 4);
        graph.edges().stream().limit(42).forEach(e -> m.append("  ").append(safe(e.source())).append(" --> ").append(safe(e.target())).append("\n"));
        if (m.toString().equals("flowchart LR\n")) m.append("  Repo[Repository] --> Files[Indexed source files]\n");
        return m.toString();
    }

    private void addTypeNodes(StringBuilder m, String label, List<GraphNode> nodes, int limit) {
        for (GraphNode n : nodes.stream().limit(limit).toList()) {
            m.append("  ").append(safe(n.id())).append("[").append(label).append(": ").append(escape(n.label())).append("]\n");
        }
    }

    private String safe(String id) { return id.replaceAll("[^a-zA-Z0-9_]", "_"); }
    private String escape(String s) { return s.replace("[", "(").replace("]", ")").replace("\"", "'"); }
    private String formatStats(Map<String, Long> stats) { return stats.entrySet().stream().map(e -> "- `" + e.getKey() + "`: " + e.getValue()).collect(Collectors.joining("\n")); }
    private String slug(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-"); }
    private String pretty(String s) { return Arrays.stream(s.split("[-_]")) .filter(w -> !w.isBlank()).map(w -> w.substring(0,1).toUpperCase() + w.substring(1)).collect(Collectors.joining(" ")); }
}
