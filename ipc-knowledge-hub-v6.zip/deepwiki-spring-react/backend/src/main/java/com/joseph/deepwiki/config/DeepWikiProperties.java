package com.joseph.deepwiki.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "deepwiki")
public class DeepWikiProperties {
    private int maxFiles = 180;
    private long maxFileBytes = 120000;
    private int cloneTimeoutSeconds = 90;

    public int getMaxFiles() { return maxFiles; }
    public void setMaxFiles(int maxFiles) { this.maxFiles = maxFiles; }
    public long getMaxFileBytes() { return maxFileBytes; }
    public void setMaxFileBytes(long maxFileBytes) { this.maxFileBytes = maxFileBytes; }
    public int getCloneTimeoutSeconds() { return cloneTimeoutSeconds; }
    public void setCloneTimeoutSeconds(int cloneTimeoutSeconds) { this.cloneTimeoutSeconds = cloneTimeoutSeconds; }
}
