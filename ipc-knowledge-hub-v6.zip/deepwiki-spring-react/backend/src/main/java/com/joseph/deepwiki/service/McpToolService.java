package com.joseph.deepwiki.service;

import com.joseph.deepwiki.model.WikiModels.*;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class McpToolService {
    private final WikiGenerationService wikiGenerationService;

    public McpToolService(WikiGenerationService wikiGenerationService) {
        this.wikiGenerationService = wikiGenerationService;
    }

    public List<McpTool> tools() {
        return List.of(
                new McpTool("github.indexRepository", "Clone and index a GitHub/GitLab/Bitbucket repository. Pass githubToken/accessToken for private GitHub repos.", Map.of("repoUrl", "string", "branch", "string", "githubToken", "string optional")),
                new McpTool("repo.search", "Search indexed files for targeted context.", Map.of("wikiId", "string", "query", "string", "limit", "number optional")),
                new McpTool("repo.getDependencies", "Return graph edges connected to a file path or graph node id.", Map.of("wikiId", "string", "pathOrNodeId", "string")),
                new McpTool("repo.explainArchitecture", "Generate a concise architecture explanation from graph evidence.", Map.of("wikiId", "string")),
                new McpTool("repo.ask", "Ask a grounded question over the indexed repository.", Map.of("wikiId", "string", "question", "string"))
        );
    }

    public McpToolCallResponse call(McpToolCallRequest request) {
        Map<String, Object> args = Optional.ofNullable(request.arguments()).orElse(Map.of());
        return switch (request.toolName()) {
            case "github.indexRepository" -> indexRepository(args);
            case "repo.search" -> search(args);
            case "repo.getDependencies" -> dependencies(args);
            case "repo.explainArchitecture" -> explain(args);
            case "repo.ask" -> ask(args);
            default -> throw new IllegalArgumentException("Unknown MCP tool: " + request.toolName());
        };
    }

    private McpToolCallResponse indexRepository(Map<String, Object> args) {
        String repoUrl = required(args, "repoUrl");
        String branch = string(args, "branch", "main");
        String token = Optional.ofNullable(string(args, "githubToken", null)).orElse(string(args, "accessToken", null));
        WikiResponse wiki = wikiGenerationService.generate(new GenerateWikiRequest(repoUrl, branch, token));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("wikiId", wiki.id());
        result.put("repoUrl", wiki.repoUrl());
        result.put("branch", wiki.branch());
        result.put("filesIndexed", wiki.files().size());
        result.put("graphNodes", wiki.architectureGraph().nodes().size());
        result.put("graphEdges", wiki.architectureGraph().edges().size());
        result.put("nodeTypeStats", wiki.architectureGraph().nodeTypeStats());
        result.put("edgeTypeStats", wiki.architectureGraph().edgeTypeStats());
        return new McpToolCallResponse("github.indexRepository", result, List.of());
    }

    private McpToolCallResponse search(Map<String, Object> args) {
        String wikiId = required(args, "wikiId");
        String query = required(args, "query");
        int limit = number(args, "limit", 10);
        List<FileSummary> files = wikiGenerationService.searchFiles(wikiId, query, limit);
        return new McpToolCallResponse("repo.search", files, files.stream().map(FileSummary::path).toList());
    }

    private McpToolCallResponse dependencies(Map<String, Object> args) {
        String wikiId = required(args, "wikiId");
        String pathOrNodeId = string(args, "pathOrNodeId", "");
        List<GraphEdge> edges = wikiGenerationService.dependencies(wikiId, pathOrNodeId);
        return new McpToolCallResponse("repo.getDependencies", edges, List.of(pathOrNodeId));
    }

    private McpToolCallResponse explain(Map<String, Object> args) {
        String wikiId = required(args, "wikiId");
        String text = wikiGenerationService.explainArchitecture(wikiId);
        return new McpToolCallResponse("repo.explainArchitecture", Map.of("markdown", text), List.of());
    }

    private McpToolCallResponse ask(Map<String, Object> args) {
        String wikiId = required(args, "wikiId");
        String question = required(args, "question");
        ChatResponse response = wikiGenerationService.chat(new ChatRequest(wikiId, question));
        return new McpToolCallResponse("repo.ask", response, response.citations());
    }

    public Map<String, Object> jsonToMap(JsonNode node) {
        Map<String, Object> result = new LinkedHashMap<>();
        if (node == null || node.isMissingNode() || node.isNull()) return result;
        node.fields().forEachRemaining(e -> {
            JsonNode v = e.getValue();
            if (v.isNumber()) result.put(e.getKey(), v.numberValue());
            else if (v.isBoolean()) result.put(e.getKey(), v.booleanValue());
            else result.put(e.getKey(), v.asText());
        });
        return result;
    }

    private String required(Map<String, Object> args, String key) {
        String value = string(args, key, null);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing required argument: " + key);
        return value;
    }

    private String string(Map<String, Object> args, String key, String defaultValue) {
        Object value = args.get(key);
        return value == null ? defaultValue : String.valueOf(value);
    }

    private int number(Map<String, Object> args, String key, int defaultValue) {
        Object value = args.get(key);
        if (value == null) return defaultValue;
        if (value instanceof Number n) return n.intValue();
        try { return Integer.parseInt(String.valueOf(value)); } catch (Exception ignored) { return defaultValue; }
    }
}
