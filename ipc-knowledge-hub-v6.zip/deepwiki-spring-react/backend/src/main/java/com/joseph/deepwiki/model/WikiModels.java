package com.joseph.deepwiki.model;

import jakarta.validation.constraints.NotBlank;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public class WikiModels {
    public record GenerateWikiRequest(@NotBlank String repoUrl, String branch, String accessToken) {}
    public record ChatRequest(@NotBlank String wikiId, @NotBlank String question) {}
    public record ChatResponse(String answer, List<String> citations) {}
    public record SearchResponse(String query, List<FileSummary> results, List<String> citations) {}
    public record FileSummary(String path, String language, long bytes, String preview) {}
    public record CodeCitation(String path, int startLine, int endLine) {}
    public record WikiPage(String id, String title, String summary, String markdown, List<String> relatedFiles) {}

    public record GraphNode(String id, String label, String type, String path, String language, String group, long bytes) {}
    public record GraphEdge(String id, String source, String target, String kind, String label) {}
    public record ArchitectureGraph(List<GraphNode> nodes, List<GraphEdge> edges, Map<String, Long> nodeTypeStats, Map<String, Long> edgeTypeStats) {}

    public record WikiResponse(
            String id,
            String repoUrl,
            String branch,
            Instant generatedAt,
            String overview,
            String architectureMermaid,
            ArchitectureGraph architectureGraph,
            List<WikiPage> pages,
            List<FileSummary> files,
            Map<String, Long> languageStats
    ) {}

    public record IndexJobResponse(String jobId, String statusUrl) {}
    public record IndexJobStatus(
            String jobId,
            String status,
            String stage,
            int progress,
            String message,
            String wikiId,
            WikiResponse wiki,
            String error,
            Instant createdAt,
            Instant updatedAt
    ) {}

    public record McpTool(String name, String description, Map<String, String> inputSchema) {}
    public record McpToolCallRequest(@NotBlank String toolName, Map<String, Object> arguments) {}
    public record McpToolCallResponse(String toolName, Object result, List<String> citations) {}
}
