CREATE TABLE t_payment_report_status (
  payment_reference VARCHAR(64) PRIMARY KEY,
  status VARCHAR(40) NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  last_updated_at TIMESTAMP NOT NULL
);

CREATE TABLE t_payment_report_daily_summary (
  summary_id BIGINT PRIMARY KEY,
  business_date DATE NOT NULL,
  total_count INTEGER NOT NULL,
  total_amount DECIMAL(18,2) NOT NULL,
  generated_at TIMESTAMP NOT NULL
);
