package com.ocbc.eps.report.api;

import com.ocbc.eps.report.service.PaymentReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/manual-payments")
public class PaymentReportController {
  private final PaymentReportService service;
  public PaymentReportController(PaymentReportService service) { this.service = service; }

  @GetMapping("/{paymentReference}/status")
  public ResponseEntity<PaymentStatusResponse> status(@PathVariable String paymentReference) {
    return ResponseEntity.ok(service.getStatus(paymentReference));
  }

  @GetMapping("/reports/daily")
  public ResponseEntity<List<PaymentStatusResponse>> dailyReport(@RequestParam String businessDate) {
    return ResponseEntity.ok(service.dailyReport(businessDate));
  }
}
