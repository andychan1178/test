package com.ocbc.eps.report.messaging;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Component
public class InwardRequestConsumer {
  @KafkaListener(topics = "${payment.kafka.topic.inward-request}", groupId = "${spring.kafka.consumer.group-id}")
  public void onInwardRequest(OutwardPaymentEvent event) {
    // Persist summarized payment status for operational inquiry and reporting.
  }
  public record OutwardPaymentEvent(String paymentReference, String debtorAccount, String creditorAccount, BigDecimal amount, String status, String submittedBy, OffsetDateTime eventTime) {}
}
