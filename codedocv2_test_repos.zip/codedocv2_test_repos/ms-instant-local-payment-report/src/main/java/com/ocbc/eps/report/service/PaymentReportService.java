package com.ocbc.eps.report.service;

import com.ocbc.eps.report.api.PaymentStatusResponse;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

@Service
public class PaymentReportService {
  public PaymentStatusResponse getStatus(String paymentReference) {
    return new PaymentStatusResponse(paymentReference, "SUBMITTED_TO_BANK", new BigDecimal("125.00"), "SGD", OffsetDateTime.now());
  }
  public List<PaymentStatusResponse> dailyReport(String businessDate) {
    return List.of(getStatus("ILP-SAMPLE-001"));
  }
}
