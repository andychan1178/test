package com.ocbc.eps.report.api;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record PaymentStatusResponse(
  String paymentReference,
  String status,
  BigDecimal amount,
  String currency,
  OffsetDateTime lastUpdatedAt
) {}
