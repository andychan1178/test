import { useState } from 'react';
import { inquireManualPayment } from '../api/paymentClient';

export default function PaymentInquiryPage() {
  const [paymentReference, setPaymentReference] = useState('ILP-SAMPLE-001');
  const [status, setStatus] = useState<string>('');
  async function onInquiry() {
    const response = await inquireManualPayment(paymentReference);
    setStatus(response.status);
  }
  return <section>
    <h2>Inquiry Manual Payment</h2>
    <input value={paymentReference} onChange={e => setPaymentReference(e.target.value)} />
    <button onClick={onInquiry}>Inquiry status</button>
    {status && <p>Status: {status}</p>}
  </section>;
}
