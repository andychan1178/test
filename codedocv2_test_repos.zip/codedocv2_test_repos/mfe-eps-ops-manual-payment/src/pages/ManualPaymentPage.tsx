import { useState } from 'react';
import { submitManualPayment } from '../api/paymentClient';

export default function ManualPaymentPage() {
  const [result, setResult] = useState<string>('');
  async function onSubmit() {
    const response = await submitManualPayment({
      debtorAccount: '001-123456-001',
      creditorAccount: '123-987654-001',
      creditorName: 'ABC Supplies Pte Ltd',
      amount: 125.00,
      currency: 'SGD',
      purposeCode: 'SUPPLIER_PAYMENT',
      remarks: 'Manual ops payment test'
    });
    setResult(response.paymentReference);
  }
  return <section>
    <h2>Submit Manual Payment</h2>
    <button onClick={onSubmit}>Submit payment</button>
    {result && <p>Submitted: {result}</p>}
  </section>;
}
