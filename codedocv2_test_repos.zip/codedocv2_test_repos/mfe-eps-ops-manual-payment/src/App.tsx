import { Link } from 'react-router-dom';
export default function App() {
  return <main>
    <h1>EPS Manual Payment Operations</h1>
    <nav>
      <Link to="/manual-payment/submit">Submit Manual Payment</Link>
      <Link to="/manual-payment/inquiry">Inquiry Payment Status</Link>
    </nav>
  </main>;
}
