import axios from 'axios';

const submitClient = axios.create({ baseURL: import.meta.env.VITE_SUBMIT_API_BASE_URL });
const reportClient = axios.create({ baseURL: import.meta.env.VITE_REPORT_API_BASE_URL });

export type SubmitPaymentRequest = {
  debtorAccount: string;
  creditorAccount: string;
  creditorName: string;
  amount: number;
  currency: string;
  purposeCode: string;
  remarks?: string;
};

export async function submitManualPayment(payload: SubmitPaymentRequest) {
  const response = await submitClient.post('/api/v1/manual-payments/submit', payload, {
    headers: { 'X-Staff-Id': 'S123456' }
  });
  return response.data;
}

export async function inquireManualPayment(paymentReference: string) {
  const response = await reportClient.get(`/api/v1/manual-payments/${paymentReference}/status`);
  return response.data;
}
