import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from './App';
import ManualPaymentPage from './pages/ManualPaymentPage';
import PaymentInquiryPage from './pages/PaymentInquiryPage';

const router = createBrowserRouter([
  { path: '/', element: <App /> },
  { path: '/manual-payment/submit', element: <ManualPaymentPage /> },
  { path: '/manual-payment/inquiry/:paymentReference?', element: <PaymentInquiryPage /> }
]);

ReactDOM.createRoot(document.getElementById('root')!).render(<RouterProvider router={router} />);
