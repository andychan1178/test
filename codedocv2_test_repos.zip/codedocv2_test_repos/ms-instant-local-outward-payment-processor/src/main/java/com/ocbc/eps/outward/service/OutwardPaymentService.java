package com.ocbc.eps.outward.service;

import com.ocbc.eps.outward.api.*;
import com.ocbc.eps.outward.messaging.OutwardPaymentEventPublisher;
import org.springframework.stereotype.Service;
import java.time.OffsetDateTime;
import java.util.UUID;

@Service
public class OutwardPaymentService {
  private final OutwardPaymentEventPublisher publisher;
  public OutwardPaymentService(OutwardPaymentEventPublisher publisher) { this.publisher = publisher; }

  public PaymentSubmitResponse submit(PaymentSubmitRequest request, String staffId) {
    String ref = "ILP-" + UUID.randomUUID();
    publisher.publishOutwardRequest(ref, request, staffId);
    return new PaymentSubmitResponse(ref, "SUBMITTED_TO_BANK", "SG_OC_EPS_INWARD_RQ", OffsetDateTime.now());
  }

  public PaymentSubmitResponse getSubmission(String paymentReference) {
    return new PaymentSubmitResponse(paymentReference, "SUBMITTED_TO_BANK", "SG_OC_EPS_INWARD_RQ", OffsetDateTime.now());
  }
}
