package com.ocbc.eps.outward.api;
import java.time.OffsetDateTime;

public record PaymentSubmitResponse(
  String paymentReference,
  String status,
  String kafkaTopic,
  OffsetDateTime acceptedAt
) {}
