package com.ocbc.eps.outward.api;

import com.ocbc.eps.outward.service.OutwardPaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/manual-payments")
public class ManualPaymentController {
  private final OutwardPaymentService service;
  public ManualPaymentController(OutwardPaymentService service) { this.service = service; }

  @PostMapping("/submit")
  public ResponseEntity<PaymentSubmitResponse> submit(@Valid @RequestBody PaymentSubmitRequest request,
      @RequestHeader("X-Staff-Id") String staffId) {
    return ResponseEntity.accepted().body(service.submit(request, staffId));
  }

  @GetMapping("/{paymentReference}")
  public ResponseEntity<PaymentSubmitResponse> getSubmission(@PathVariable String paymentReference) {
    return ResponseEntity.ok(service.getSubmission(paymentReference));
  }
}
