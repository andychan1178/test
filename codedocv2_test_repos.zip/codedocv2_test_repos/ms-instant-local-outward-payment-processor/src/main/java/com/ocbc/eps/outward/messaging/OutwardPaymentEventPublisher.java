package com.ocbc.eps.outward.messaging;

import com.ocbc.eps.outward.api.PaymentSubmitRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Component
public class OutwardPaymentEventPublisher {
  private final KafkaTemplate<String, OutwardPaymentEvent> kafkaTemplate;
  private final String topic;
  public OutwardPaymentEventPublisher(KafkaTemplate<String, OutwardPaymentEvent> kafkaTemplate,
      @Value("${payment.kafka.topic.outward-request}") String topic) {
    this.kafkaTemplate = kafkaTemplate; this.topic = topic;
  }
  public void publishOutwardRequest(String ref, PaymentSubmitRequest req, String staffId) {
    kafkaTemplate.send(topic, ref, new OutwardPaymentEvent(ref, req.debtorAccount(), req.creditorAccount(), req.amount(), "SUBMITTED_TO_BANK", staffId, OffsetDateTime.now()));
  }
  public record OutwardPaymentEvent(String paymentReference, String debtorAccount, String creditorAccount, BigDecimal amount, String status, String submittedBy, OffsetDateTime eventTime) {}
}
