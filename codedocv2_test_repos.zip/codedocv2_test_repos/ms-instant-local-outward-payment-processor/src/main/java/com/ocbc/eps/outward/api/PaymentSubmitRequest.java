package com.ocbc.eps.outward.api;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record PaymentSubmitRequest(
  @NotBlank String debtorAccount,
  @NotBlank String creditorAccount,
  @NotBlank String creditorName,
  @NotNull @DecimalMin("0.01") BigDecimal amount,
  @NotBlank String currency,
  @NotBlank String purposeCode,
  String remarks
) {}
