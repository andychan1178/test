package com.ocbc.eps.outward;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class OutwardPaymentProcessorApplication {
  public static void main(String[] args) { SpringApplication.run(OutwardPaymentProcessorApplication.class, args); }
}
