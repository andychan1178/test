CREATE TABLE t_outward_payment_instruction (
  payment_reference VARCHAR(64) PRIMARY KEY,
  debtor_account VARCHAR(34) NOT NULL,
  creditor_account VARCHAR(34) NOT NULL,
  creditor_name VARCHAR(140) NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  purpose_code VARCHAR(20) NOT NULL,
  status VARCHAR(40) NOT NULL,
  submitted_by VARCHAR(50) NOT NULL,
  created_at TIMESTAMP NOT NULL
);

CREATE TABLE t_outward_payment_audit (
  audit_id BIGINT PRIMARY KEY,
  payment_reference VARCHAR(64) NOT NULL,
  action VARCHAR(40) NOT NULL,
  actor VARCHAR(50) NOT NULL,
  audit_time TIMESTAMP NOT NULL
);
