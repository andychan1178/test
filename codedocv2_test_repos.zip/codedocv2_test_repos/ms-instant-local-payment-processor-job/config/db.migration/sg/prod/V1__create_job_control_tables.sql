CREATE TABLE t_payment_job_run_control (
  job_run_id BIGINT PRIMARY KEY,
  job_name VARCHAR(80) NOT NULL,
  job_status VARCHAR(30) NOT NULL,
  started_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP NULL
);
