package com.ocbc.eps.job.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class PaymentReconciliationScheduler {
  @Scheduled(cron = "${payment.job.reconciliation.cron}")
  public void reconcilePendingPayments() {
    // Scan pending payment instructions and reconcile with host/status report.
  }

  @Scheduled(cron = "${payment.job.archive.cron}")
  public void archiveCompletedPayments() {
    // Archive completed payment records older than operational retention window.
  }
}
