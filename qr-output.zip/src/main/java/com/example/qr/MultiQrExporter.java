package com.example.qr;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.common.BitMatrix;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class MultiQrExporter {

    private static final int DEFAULT_QR_SIZE = 900;
    private static final int DEFAULT_CHUNK_SIZE = 650;
    private static final int MARGIN = 3;

    private MultiQrExporter() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2 || args.length > 4) {
            System.out.println("""
                    Usage:
                      java -jar target/textfile-to-multi-qr-1.0.0.jar <input.txt> <output-folder> [qr-size] [chunk-size]

                    Example:
                      java -jar target/textfile-to-multi-qr-1.0.0.jar input.txt qr-output
                      java -jar target/textfile-to-multi-qr-1.0.0.jar input.txt qr-output 900 650

                    Notes:
                      - Use chunk-size 500 to 800 for mobile-friendly scanning.
                      - Very large chunks create dense QR codes and scan badly.
                    """);
            System.exit(1);
        }

        Path inputFile = Path.of(args[0]);
        Path outputFolder = Path.of(args[1]);
        int qrSize = args.length >= 3 ? Integer.parseInt(args[2]) : DEFAULT_QR_SIZE;
        int chunkSize = args.length >= 4 ? Integer.parseInt(args[3]) : DEFAULT_CHUNK_SIZE;

        if (!Files.exists(inputFile)) {
            throw new IllegalArgumentException("Input file does not exist: " + inputFile);
        }

        if (qrSize < 400) {
            throw new IllegalArgumentException("QR size should be at least 400.");
        }

        if (chunkSize < 100 || chunkSize > 1200) {
            throw new IllegalArgumentException("Chunk size should be between 100 and 1200. Recommended: 500 to 800.");
        }

        Files.createDirectories(outputFolder);

        String content = Files.readString(inputFile, StandardCharsets.UTF_8);
        if (content.isBlank()) {
            throw new IllegalArgumentException("Input file is empty.");
        }

        String contentHash = sha256Short(content);
        List<String> chunks = splitText(content, chunkSize);

        System.out.println("Input file      : " + inputFile.toAbsolutePath());
        System.out.println("Output folder   : " + outputFolder.toAbsolutePath());
        System.out.println("Content length  : " + content.length() + " characters");
        System.out.println("Chunk size      : " + chunkSize + " characters");
        System.out.println("Total QR images : " + chunks.size());
        System.out.println("Content hash    : " + contentHash);

        for (int i = 0; i < chunks.size(); i++) {
            int partNo = i + 1;
            String payload = buildPayload(contentHash, partNo, chunks.size(), chunks.get(i));
            Path out = outputFolder.resolve(String.format("qr-part-%03d-of-%03d.png", partNo, chunks.size()));
            generateQr(payload, out, qrSize);
            System.out.println("Generated: " + out.getFileName());
        }

        Path manifest = outputFolder.resolve("manifest.txt");
        Files.writeString(manifest, buildManifest(inputFile, content, chunks.size(), chunkSize, contentHash), StandardCharsets.UTF_8);

        System.out.println();
        System.out.println("Done.");
        System.out.println("Scan QR images in order: qr-part-001, qr-part-002, ...");
        System.out.println("Each scan contains a header plus that chunk of text.");
        System.out.println("Manifest: " + manifest.toAbsolutePath());
    }

    private static String buildPayload(String hash, int partNo, int totalParts, String chunk) {
        return """
                [MULTI-QR-TEXT]
                ID: %s
                PART: %d/%d
                COPY-BELOW:
                %s
                """.formatted(hash, partNo, totalParts, chunk);
    }

    private static List<String> splitText(String text, int maxChunkSize) {
        List<String> chunks = new ArrayList<>();
        int start = 0;

        while (start < text.length()) {
            int end = Math.min(start + maxChunkSize, text.length());

            if (end < text.length()) {
                int niceBreak = findNiceBreak(text, start, end);
                if (niceBreak > start) {
                    end = niceBreak;
                }
            }

            chunks.add(text.substring(start, end));
            start = end;
        }

        return chunks;
    }

    private static int findNiceBreak(String text, int start, int proposedEnd) {
        int newline = text.lastIndexOf('\n', proposedEnd);
        if (newline > start + 100) {
            return newline + 1;
        }

        int sentence = Math.max(
                text.lastIndexOf(". ", proposedEnd),
                Math.max(text.lastIndexOf("? ", proposedEnd), text.lastIndexOf("! ", proposedEnd))
        );
        if (sentence > start + 100) {
            return sentence + 2;
        }

        int space = text.lastIndexOf(' ', proposedEnd);
        if (space > start + 100) {
            return space + 1;
        }

        return proposedEnd;
    }

    private static void generateQr(String payload, Path outputFile, int size) throws Exception {
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.CHARACTER_SET, StandardCharsets.UTF_8.name());
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, MARGIN);

        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix matrix = writer.encode(payload, BarcodeFormat.QR_CODE, size, size, hints);

        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        int black = Color.BLACK.getRGB();
        int white = Color.WHITE.getRGB();

        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? black : white);
            }
        }

        ImageIO.write(image, "PNG", outputFile.toFile());
    }

    private static String sha256Short(String value) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
        String b64 = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        return b64.substring(0, 12);
    }

    private static String buildManifest(Path inputFile, String content, int totalParts, int chunkSize, String hash) {
        return """
                Multi QR Export Manifest

                Input File      : %s
                Content Length  : %d characters
                Total QR Images : %d
                Chunk Size      : %d
                Content Hash    : %s

                Mobile Scanning Instructions:
                1. Open phone QR scanner.
                2. Scan qr-part-001 first.
                3. Copy the text after COPY-BELOW.
                4. Continue scanning in order until the last part.
                5. Paste all copied chunks into Notes, WhatsApp, email, or any text editor.
                6. Remove the [MULTI-QR-TEXT] headers if you only need the raw content.

                Practical Advice:
                - If scanning is difficult, regenerate with smaller chunk size, for example 500.
                - If there are too many QR files, increase chunk size slowly, for example 750 or 900.
                - Do not push chunk size too high. Dense QR codes are painful on mobile.
                """.formatted(inputFile.toAbsolutePath(), content.length(), totalParts, chunkSize, hash);
    }
}
